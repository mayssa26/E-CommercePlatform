package sistema;

public class EnlaceServer{
  private EjecutorServer ejS;

  public EnlaceServer(String numero,EnlaceSend grafico){
    ejS=new EjecutorServer(numero,grafico);
    ejS.start();
  }

  //Este es el metodo para invocar desde el exterior.
  public Object send(int com,Object data,int dest){
    return(ejS.send(com,data,dest));
  }
  
  public int dameIDServer(){
    return(ejS.dameID());
  }

  public void close(){
    ejS.close();
  }

}