package sistema;

public class EnlaceClient{
  private EjecutorClient ejC;

  public EnlaceClient(String ip,String numero,EnlaceSend grafico){
    ejC=new EjecutorClient(ip,numero,grafico);
    ejC.start();
  }

  //Este es el metodo para invocar desde el exterior.
  public Object send(int com,Object data,int dest){
    return(ejC.send(com,data,dest));
  }
  
  public int dameIDClient(){
    return(ejC.dameID());
  }
  
  public void close(){
    ejC.close();
  }

}