package sistema;

public interface EnlaceSend{
  public Object send(int com,Object data,int dest);
}