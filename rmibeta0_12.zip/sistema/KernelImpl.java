package sistema;

import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.server.ServerNotActiveException;
import java.util.Hashtable;
import java.util.Enumeration;
import java.net.InetAddress;
import java.net.UnknownHostException;

import sistema.util.NodoData;
import sistema.util.Destino;

public class KernelImpl extends UnicastRemoteObject implements KernelInterface{
  private int vecindario;
  private int idUnico;
  private Hashtable vecinos;
  private Ejecutor cs;
  private boolean estrella=true;
  private Daemon demonio;
  private EnlaceSend grafico;
  private Hashtable caminos;

  public KernelImpl(int vecindario,int idUnico,Ejecutor cs,EnlaceSend grafico)
  throws RemoteException{
    super();
    try{
      Naming.rebind("p"+idUnico,this);
    }catch(Exception e){
      println(""+e);
      System.exit(0);
    }
    this.vecindario=vecindario;
    this.idUnico=idUnico;
    this.cs=cs;
    vecinos=new Hashtable();
    caminos=new Hashtable();
    this.grafico=grafico;
    demonio=new Daemon(cs,6500);
  }

//-------------------Inicio de Remotes------------------

  //Remoto Send Real
  public Object send(int ruta[],int com,Object data,int orig){    
    if(ruta.length<=1)return(grafico.send(com,data,orig));
    else{
      ruta=removeFirst(ruta);
      int sig=ruta[0];
      KernelInterface conecta=null; 
      if(Destino.vecindario(sig)==sig){
        conecta=cs.salidaServer();
      }
      else{
        NodoData nodo=(NodoData)vecinos.get(new Integer(sig));
        if((nodo!=null)&&(nodo.con!=null))conecta=nodo.con;
      }
      if(conecta!=null){
        try{      
          return(conecta.send(ruta,com,data,orig));
        }catch(Exception e1){}
      }
    }
    return(null);
  }

  //Local  
  //proceso que hace la busqueda de caminos y luego envia el mensaje.
  public Object sendLocal(int com,Object data,int dest){
    int ruta[]=(int [])caminos.get(new Integer(dest));
    //Si ya tenias conocimiento de esta ruta.
    if(ruta!=null){
      println("usando ruta previa..");
      Object resp=send(ruta,com,data,idUnico);
      if(resp!=null)return(resp);
      println("ruta previa invalida..");
      caminos.remove(new Integer(dest)); 
    }
    int listaM[]=new int[1];
    listaM[0]=idUnico;
    println("localizando ruta..");
    ruta=buscaRuta(listaM,dest);
    //Localizo la ruta
    if(ruta!=null){
      Object resp=send(ruta,com,data,idUnico);
      if(resp!=null)caminos.put(new Integer(dest),ruta);
      else caminos.remove(new Integer(dest));
      return(resp);
    }
    return(null);
  }

  //Remoto
  public int dameId(){
    return(cs.dameId());
  }

  //Remoto
  //Solicitado por un cliente que tiene un enlace hacia ti ya seas server/client
  public boolean nuevaConexion(int id){
    String host="";
    try{
      host=getClientHost();      
    }catch(ServerNotActiveException e){}
    return(addNodo(host,id,true));
  }

  //Remoto
  public char[][] dameVecinos(){
    int qty=vecinos.size();
    char all[][]=new char[qty][0];
    char vec[][]=new char[qty][0];
    int can=0,sen=0;
    if(qty>0){
      int id;
      NodoData nodo;
      String valor;
      Enumeration e=vecinos.keys();
      while(e.hasMoreElements()){
        id=((Integer)e.nextElement()).intValue();
        nodo=(NodoData)vecinos.get(new Integer(id));
        valor=nodo.ip+"|"+id;
        all[can++]=valor.toCharArray();
        //if(Destino.vecindario(id)==vecindario)vec[sen]=all[sen++];
      }
    }
    /*if(sen!=can){
      char data[][]=new char[sen][0];
      for(int i=0;i<sen;i++)data[i]=vec[i];
      return data;        
    }*/
    return(all);
  }

  //Remoto
  public void enviaTabla(char tabla[][],boolean informaV,char name[]){
    if(informaV){
      println("Informando de la tabla a Vecinos");
      enviaTablaVecinos(tabla,name);
    }
    println("Recibiendo tabla..");
    for(int i=0;i<tabla.length;i++)anunciaVecino(tabla[i]);
    if(!informaV&&(name!=null))anunciaVecino(name); 
  }

  //Remoto
  public boolean anilloCordado(){
    return !estrella;
  }

  //Remoto
  public void solicitaCambioAnillo(){
    estrella=false;
  }
  
  //Remoto
  public void notificaNuevoVecino(char name[],boolean foraneo){
    if(foraneo)notificaForaneos(name);
    anunciaVecino(name);
  }

  //Remoto
  public int[] buscaRuta(int lista[],int destino){
    if((destino==vecindario)&&(cs.salidaServer()!=null))return(addLista(lista,destino));
    if(destino==idUnico)return(addLista(lista,destino));
    int qty=vecinos.size();
    if(qty>0){      
      NodoData nodo;
      int id;
      nodo=(NodoData)vecinos.get(new Integer(destino));
      if((nodo!=null)&&(nodo.con!=null))return(addLista(lista,destino));
      Enumeration e=vecinos.keys();
      KernelInterface vecino;
      String nodoName;
      int listaRecibida[];
      while(e.hasMoreElements()){
        id=((Integer)e.nextElement()).intValue(); 
        if(!contains(lista,id)){
          nodo=(NodoData)vecinos.get(new Integer(id));
          if((nodo!=null)&&(nodo.con!=null)){
            if(id==destino)return(addLista(lista,id));
            try{      
              listaRecibida=nodo.con.buscaRuta(addLista(lista,id),destino);
              if(listaRecibida!=null)return(listaRecibida); 
            }catch(Exception e1){}
          }
        }
      }
    }
    KernelInterface salidaServer=cs.salidaServer();
    if(salidaServer!=null){
      try{
        int listaRecibida[]=salidaServer.buscaRuta(addLista(lista,vecindario),destino);
        return(listaRecibida);
      }catch(Exception e1){}
    }
    return(null);
  }

//---------------------Fin de Remotes-------------------

//Local
//se invoca cuando se recibe una conexion para notificar a los vecinos.
//con 0 para chequeo y el id para cuando se necesite enviar.

  private int[] addLista(int lista[],int dato){
    int nueva[]=new int[lista.length+1];
    int i=0;
    for(;i<lista.length;i++)nueva[i]=lista[i];
    nueva[i]=dato;
    return(nueva);
  }

  private int[] removeFirst(int lista[]){
    int nueva[]=new int[lista.length-1];
    for(int i=0;i<nueva.length;i++)nueva[i]=lista[i+1];
    return(nueva);
  }

  private boolean contains(int lista[],int dato){
    boolean resp=false;
    for(int i=0;i<lista.length;i++)
    if(lista[i]==dato){
      resp=true;
      break;
    }
    return(resp);
  }

  public KernelInterface isAlive(String ip,int id){
    KernelInterface informa=null;
    String nodoName=ip+"/p"+id;
    try{
      informa=(KernelInterface)Naming.lookup("rmi://"+nodoName);
    }catch(Exception e){}
    return(informa);
  }

  private boolean notificaVecinos(int idNotificar,boolean quita){
    int qty=vecinos.size();
    boolean resp=false; 
    if(qty>0){      
      NodoData nodo;
      int id;
      Enumeration e=vecinos.keys();
      String nodoName;
      boolean foraneo=Destino.vecindario(idUnico)==idUnico;
      while(e.hasMoreElements()){
        id=((Integer)e.nextElement()).intValue();
        nodo=(NodoData)vecinos.get(new Integer(id));
        if((nodo!=null)&&(nodo.con!=null)){
          if(idNotificar==0){
            nodo.con=isAlive(nodo.ip,id);
            if(nodo.con==null){
              if(quita){
                try{
                  Naming.unbind("p"+id);
                }catch(Exception e1){}
                vecinos.remove(new Integer(id));
              }
              resp=true;
            } 
          } 
          else{
            try{
              nodo.con.notificaNuevoVecino((nodo.ip+"|"+idNotificar).toCharArray(),foraneo);
            }catch(RemoteException e1){
              nodo.con=null;
              if(quita)vecinos.remove(new Integer(id));
              resp=true;
            } 
          }
        }
      }
    }
    return(resp);
  }

  private void notificaForaneos(char name[]){
    String data=new String(name);
    String ipr=NodoData.splitIP(data);
    int idr=NodoData.splitID(data);
    KernelInterface back=isAlive(ipr,idr);
    int qty=vecinos.size();
    if(qty>0){      
      NodoData nodo;
      int id;
      Enumeration e=vecinos.keys();
      KernelInterface con;
      String vecinoLejano;
      while(e.hasMoreElements()){
        id=((Integer)e.nextElement()).intValue();
        nodo=(NodoData)vecinos.get(new Integer(id));
        if((nodo!=null)&&(Destino.vecindario(id)!=vecindario)){
          if(nodo.con==null)con=isAlive(nodo.ip,id);
          else con=nodo.con;
          if(con!=null){
            try{
              con.notificaNuevoVecino(name,false);
            }catch(RemoteException e1){} 
          }
          vecinoLejano=(nodo.ip+"|"+id);
          if(back!=null){
            try{
              back.notificaNuevoVecino(vecinoLejano.toCharArray(),false);
            }catch(RemoteException e2){}
          }
        }   
      }
    }    
  }

  public void conectaCordados(){
    int qty=vecinos.size();
    if(qty>0){      
      NodoData nodo;
      int id;
      Enumeration e=vecinos.keys();
      KernelInterface vecino;
      String nodoName;
      while(e.hasMoreElements()){
        id=((Integer)e.nextElement()).intValue();
        nodo=(NodoData)vecinos.get(new Integer(id));
        if(nodo!=null){
          if(nodo.con==null){
            nodoName=nodo.ip+"/p"+id;
            try{
              vecino=(KernelInterface)Naming.lookup("rmi://"+nodoName);
              nodo.con=vecino;
            }catch(Exception e1){
              vecinos.remove(new Integer(id));
            }
          }
        }
      }
    }
  }

  //Local
  public void checaEnlaces(boolean quita){
    boolean pasaAnillo=notificaVecinos(0,quita);
    if(pasaAnillo)cs.pierdeConexion();
    if(estrella&&pasaAnillo)estrella=false;
  }

  //Local
  private void enviaTablaVecinos(char tabla[][],char name[]){
    int qty=vecinos.size();
    if(qty>0){      
      NodoData nodo;
      int id;
      Enumeration e=vecinos.keys();
      KernelInterface informa;
      while(e.hasMoreElements()){
        id=((Integer)e.nextElement()).intValue();
        //if(Destino.vecindario(id)==vecindario){
          nodo=(NodoData)vecinos.get(new Integer(id));
          if(nodo!=null){
            if(nodo.con!=null){
              try{
                nodo.con.enviaTabla(tabla,false,name);
              }catch(RemoteException e1){
                nodo.con=null;
              } 
            }
            else{ 
              try{
                informa=(KernelInterface)Naming.lookup("rmi://"+nodo.ip+"/p"+id);
                informa.enviaTabla(tabla,false,name);
              }catch(Exception e2){}
            }
          }
        //}
      }
    }
  }

  //Local
  public boolean addNodo(String ip,int id,boolean conectar){
    boolean respuesta=false;
    if( (id!=idUnico) && (!existeConexion(id)) ){
      String nodoName=ip+"/p"+id;
      KernelInterface vecino=null;
      if(conectar){
        try{
          vecino=(KernelInterface)Naming.lookup("rmi://"+nodoName);
          //Si eres server, notificaras a tus vecinos.
          if(vecindario==idUnico){
            println("Notificando a clients..");
            boolean pasaAnillo=notificaVecinos(id,false);
            if(estrella&&pasaAnillo)estrella=false;
          }
        }catch(Exception e){}
      }
      vecinos.put(new Integer(id),new NodoData(vecino,ip));
      println("Recibi Vecino! "+nodoName);
      cs.cursor();
      respuesta=true; 
    }
    return(respuesta);
  }

  //Local
  public boolean addFarConexion(String ip,int id){
    boolean respuesta=false;
    if(!existeConexion(id)){
      String nodoName=ip+"/p"+id;
      char miName[]=(localIP()+"|"+idUnico).toCharArray();
      try{
        println("Busqueda de Vecino Lejano..");
        KernelInterface vecino=(KernelInterface)Naming.lookup("rmi://"+nodoName);
        //println("Obteniendo mi lista de Vecinos..");
        char MyList[][]=dameVecinos();
        println("Obteniendo lista de Vecinos Lejana..");
        char SuList[][]=vecino.dameVecinos();
        println("Enviando Lista..");
        vecino.enviaTabla(MyList,true,miName);
        enviaTabla(SuList,true,(ip+"|"+id).toCharArray());
        vecino.nuevaConexion(idUnico);        
        println("Recibi Vecino Lejano..!");
        vecinos.put(new Integer(id),new NodoData(vecino,ip));
        respuesta=true; 
      }catch(Exception e){}    
    }
    return(respuesta);
  }

  //Local
  public boolean existeConexion(int id){
    NodoData nodo=null;
    nodo=(NodoData)vecinos.get(new Integer(id));
    if(nodo==null)return(false); 
    if(nodo.con==null)nodo.con=isAlive(nodo.ip,id);
    return(nodo.con!=null);
    /*if((nodo!=null)&&(nodo.con!=null)){
      nodo.con=isAlive(nodo.ip,id);
    }
    return(resp);
    */
  }

  public void anunciaVecino(char name[]){
    if(vecindario!=idUnico){
      String data=new String(name);
      String ip=NodoData.splitIP(data);
      int id=NodoData.splitID(data);
      if(id!=idUnico){
        NodoData nodo=(NodoData)vecinos.get(new Integer(id));
        if(nodo==null){
          KernelInterface vecino=null;
          if(!estrella){
            String nodoName=ip+"/p"+id;
            try{
              vecino=(KernelInterface)Naming.lookup("rmi://"+nodoName);
            }catch(Exception e){}          
          }
          vecinos.put(new Integer(id),new NodoData(vecino,ip));
          println("Vecino Anunciado! "+Destino.vecindario(id)+"."+Destino.vecino(id));
          cs.cursor();
        } 
      }
    }
  }

  //Local
  public void listOut(boolean showCursor){
    int qty=vecinos.size();
    if(qty>0){      
      println("Lista de Conexiones:");
      int id;
      NodoData nodo;
      Enumeration e=vecinos.keys();
      KernelInterface con;
      while(e.hasMoreElements()){
        id=((Integer)e.nextElement()).intValue();
        nodo=(NodoData)vecinos.get(new Integer(id));
        if(nodo!=null){         
          //if(nodo.con==null)nodo.con=isAlive(nodo.ip,id);
          System.out.print(nodo.ip+" "+id+" "+Destino.vecindario(id)+"."+Destino.vecino(id));
          if(nodo.con!=null)println(" Conect");
          else println(" noConect");
        }
      }
      if(showCursor)cs.cursor();
    }
  }

  public void ReConect(){
    int qty=vecinos.size();
    estrella=false;
    if(qty>0){      
      println("Reconectando Enlaces");
      int id;
      NodoData nodo;
      Enumeration e=vecinos.keys();
      KernelInterface con;
      while(e.hasMoreElements()){
        id=((Integer)e.nextElement()).intValue();
        nodo=(NodoData)vecinos.get(new Integer(id));
        if(nodo!=null)nodo.con=isAlive(nodo.ip,id);
      }
    }
  }

  public String localIP(){
    String ip="localhost";
    try{
      ip=(InetAddress.getLocalHost()).getHostAddress();
    }catch(UnknownHostException e){}
    return(ip);
  }
  //Local
  public int dameIdUnico(){
    return(idUnico); 
  }
  //Local
  public int dameVecindario(){
    return(vecindario);
  }
  //Local
  public boolean dameEstrella(){
    return estrella;
  }
  //Local
  public void desactivaEstrella(){
    estrella=false; 
  }
  //Local
  public void iniciarDaemon(){
    demonio.start();
  }
  public void quitaServicio(){
    try{
      Naming.unbind("p"+idUnico);
    }catch(Exception e){}
  }
  //Local
  private void println(String m){
    System.out.println(m);
  }

  public void busca(int dest){
    int listaM[]=new int[1];
    listaM[0]=idUnico;
    int lista[]=buscaRuta(listaM,dest);
    if(lista!=null){
      for(int i=0;i<lista.length;i++)
      System.out.print("->"+Destino.vecindario(lista[i])+"."+Destino.vecino(lista[i]));
      println("");
    }
    else println("No se encontro camino.");
  }

}