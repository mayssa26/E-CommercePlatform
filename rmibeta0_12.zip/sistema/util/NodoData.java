package sistema.util;
import sistema.KernelInterface;

public class NodoData{
  public KernelInterface con;
  public String ip;
  public NodoData(KernelInterface con,String ip){
    this.con=con;
    this.ip=ip;
  }
  public static String splitIP(String datap){
    String valor="";
    int i;
    for(i=0;i<datap.length();i++){
      if(datap.charAt(i)=='|')break;
      else valor=valor+datap.charAt(i);
    }
    return(valor);
  }
  public static int splitID(String datap){
    String valor=""; 
    int i;
    for(i=datap.length()-1;i>0;i--){
      if(datap.charAt(i)=='|')break;
      else valor=datap.charAt(i)+valor;
    }
    try{
      return(Integer.parseInt(valor)); 
    }catch(NumberFormatException e){}
    return(0);
  }
}