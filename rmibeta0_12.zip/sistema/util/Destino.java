package sistema.util;

public abstract class Destino{
  public static int creaDest(int vecindario,int vecino){
    vecino=vecino<<16;
    return(vecino+vecindario);
  }
  public static int vecino(int dest){
    return(dest>>16);
  }
  public static int vecindario(int dest){
    return((int)(short)dest);
  }
}