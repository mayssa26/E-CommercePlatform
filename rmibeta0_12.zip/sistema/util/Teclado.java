package sistema.util;

import java.io.*;

public class Teclado{
  public String read(){
    InputStreamReader ir = new InputStreamReader(System.in);
    BufferedReader in = new BufferedReader(ir);     
    String s,r;
    r=new String();     
    try{      
      s = in.readLine();
      r = new String(s);
    }catch(IOException e){e.printStackTrace();}
    return(r);
  }
}