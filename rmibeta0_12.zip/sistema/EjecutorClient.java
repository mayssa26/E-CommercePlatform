package sistema;
import java.rmi.*;
import java.rmi.registry.*;
import java.rmi.server.*;
import java.util.Date;
import sistema.util.Teclado;
import sistema.util.Destino;
import sistema.util.NodoData;

public class EjecutorClient extends Thread implements Ejecutor{
  private KernelInterface server=null;
  private KernelImpl conexion=null;
  private String ipServer="localhost";
  private EnlaceSend grafico;

  public EjecutorClient(String ip,String numero,EnlaceSend grafico){
    this.grafico=grafico;
    int vecindario=0;
    int idClient=0;
    try{
      vecindario=Integer.parseInt(numero);
    }catch(NumberFormatException e){
      println("Error en Numero para Servidor.."+numero);
      System.exit(0);
    }
    ipServer=ip;
    String nombreServidor=ip+"/p"+numero;
    System.setSecurityManager(new RMISecurityManager());
    println("Buscando Servidor RMI:"+nombreServidor+"..");
    try{
      server=(KernelInterface)Naming.lookup("rmi://"+nombreServidor);
      println("RMI object successful "+nombreServidor);
    }catch(Exception e){
      println("Error en server:"+nombreServidor);
      println(""+e);
      System.exit(0);
    }
    println("Solicitando ID..");
    try{
      idClient=server.dameId();
    }catch(Exception e){
      println("Error en server:"+nombreServidor);
      println(""+e);
      System.exit(0);
    }
    if(idClient==0){
      println("Error por conexion a un vecino..");
      System.exit(0);
    }
    int idUnico=Destino.creaDest(vecindario,idClient);
    println("Creando servicio..");
    try{
      conexion=new KernelImpl(vecindario,idUnico,this,grafico);
      println("Cliente Activado como Puente: p"+idUnico);
    }catch (Exception e){
      println("Error al crear Puente");
      println(""+e);
      System.exit(0);
    }
    println("Solicitando Lista de Vecinos de "+nombreServidor+"..");
    char tabla[][]=new char[0][0];
    try{
      tabla=server.dameVecinos();
    }catch(Exception e){}
    conexion.enviaTabla(tabla,false,null);
    println("Solicitando agregar conexion BiDireccional..");
    boolean respuesta=false;
    try{
      respuesta=server.nuevaConexion(idUnico);
    }catch(Exception e){
      println("Error en server:"+nombreServidor);
      println(""+e);
      conexion.quitaServicio();
      System.exit(0);
    }
    if(!respuesta){
      println("No se pudo crear conexion server->client");
      conexion.quitaServicio();
      System.exit(0);  
    }
    respuesta=false;
    try{
      respuesta=server.anilloCordado();
    }catch(Exception e){}
    if(respuesta){
      conexion.conectaCordados();
      conexion.desactivaEstrella();
    }
    lista();
    conexion.iniciarDaemon();
  }

  public int dameID(){
    return(conexion.dameIdUnico());
  }

  public void close(){
    conexion.quitaServicio();
    System.exit(0);
  }

  public Object send(int com,Object data,int dest){
    return(conexion.sendLocal(com,data,dest));
  }

  public void run(){
    Teclado lector=new Teclado();
    String s,ip;
    int idVecindario,idVecino;
    boolean resp;
    Object testObj;
    int opc=0;    
    do{
      opc=0;
      cursor();
      s=new String(lector.read());
      if(s.equals("exit"))opc=99;
      if(s.equals("send"))opc=1;
      if(s.equals("list"))opc=2;
      if(s.equals("connect"))opc=3;
      if(s.equals("recon"))opc=4;
      if(s.equals("find"))opc=5;
      switch(opc){
        case 1:
          println("Input destino:");
          System.out.print("Vecindario:");
          s=new String(lector.read());
          try{
            idVecindario=Integer.parseInt(s);
          }catch(NumberFormatException e1){
            println("Error Numerico Vecindario");
            break;
          }
          System.out.print("Vecino:");
          s=new String(lector.read());
          try{
            idVecino=Integer.parseInt(s);
          }catch(NumberFormatException e1){
            println("Error Numerico Vecino");
            break;
          }
          System.out.print("Mensaje:");
          s=new String(lector.read());
          testObj=send(256,s,Destino.creaDest(idVecindario,idVecino));
          if(testObj!=null)println("Envio Correcto.");
          else println("Fail");   
        break;
        case 2:lista();break;    
        case 3:
          System.out.print("IP to connect:");
          ip=new String(lector.read());
          System.out.print("Vecindario:");
          s=new String(lector.read());
          try{
            idVecindario=Integer.parseInt(s);
          }catch(NumberFormatException e1){
            println("Error Numerico Vecindario");
            break;
          }
          System.out.print("Vecino:");
          s=new String(lector.read());
          try{
            idVecino=Integer.parseInt(s);
          }catch(NumberFormatException e1){
            println("Error Numerico Vecino");
            break;
          }
          if(idVecino<1){
            println("Vecino lejano debe ser>0");
            break; 
          }
          if(conexion.addFarConexion(ip,Destino.creaDest(idVecindario,idVecino))){
            println("Ok!"); 
          }
          else println("Fallo al conectar..");
        break;
        case 4:
          if(server==null)server=conexion.isAlive(ipServer,conexion.dameVecindario());
          conexion.ReConect();
        break; 
        case 5:
          println("Input destino:");
          System.out.print("Vecindario:");
          s=new String(lector.read());
          try{
            idVecindario=Integer.parseInt(s);
          }catch(NumberFormatException e1){
            println("Error Numerico Vecindario");
            break;
          }
          System.out.print("Vecino:");
          s=new String(lector.read());
          try{
            idVecino=Integer.parseInt(s);
          }catch(NumberFormatException e1){
            println("Error Numerico Vecino");
            break;
          }
          conexion.busca(Destino.creaDest(idVecindario,idVecino));
        break;
        //case 99:salir();break;
      }       
    }while(opc!=99);
    conexion.quitaServicio();
    System.exit(0);
  }

  private void lista(){
    if(server==null){
      println("No hay salida al Server..");
    }
    if(conexion.dameEstrella())println("Estrella");
    else println("Anillo Cordado");
    conexion.listOut(false);
  }

  private void println(String m){
    System.out.println(m);
  }

  public int dameId(){
    return(0);
  }  

  public Object send(int orig,int instruction,Object data,int dest){
    Object respuesta=null;
    return(respuesta);
  }

  public void cursor(){
    System.out.print("<C"+conexion.dameVecindario()+".");
    System.out.print(Destino.vecino(conexion.dameIdUnico())+">$ ");
  }

  public void pierdeConexion(){
    if(conexion.dameEstrella()){
      if(server!=null){
        println("Cliente Perdio Conexion..");
        println("Avisando al server..");
        try{        
          server.solicitaCambioAnillo();
        }catch(Exception e){
          server=null;
        }
      }
    }
  }

  public KernelInterface salidaServer(){
    return(server);
  }

  public void runRMI(){
    boolean cordado=true;
    if(server!=null){
      try{
        cordado=server.anilloCordado();
      }catch(Exception e){
        server=null; 
      }
    }       
    if(cordado||!conexion.dameEstrella()){
      conexion.conectaCordados();
      if(conexion.dameEstrella()){ 
        conexion.desactivaEstrella();
        conexion.listOut(true);
      }
    }
    conexion.checaEnlaces(false);
  }

}