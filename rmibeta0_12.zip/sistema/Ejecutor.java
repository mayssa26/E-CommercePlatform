package sistema;

public interface Ejecutor{
  public int dameId();
  public void pierdeConexion();
  public void cursor();
  public void runRMI();
  public KernelInterface salidaServer();
}