package sistema;

import java.rmi.RemoteException;
import java.rmi.Remote;

public interface KernelInterface extends Remote{
  public Object send(int ruta[],int com,Object data,int orig) throws RemoteException;
  public int dameId()throws RemoteException;
  public boolean nuevaConexion(int id) throws RemoteException;
  public char[][] dameVecinos() throws RemoteException;
  public void enviaTabla(char tabla[][],boolean informaV,char name[]) throws RemoteException;
  public boolean anilloCordado() throws RemoteException;
  public void solicitaCambioAnillo() throws RemoteException;
  public void notificaNuevoVecino(char name[],boolean foraneo) throws RemoteException;
  public int[] buscaRuta(int lista[],int destino) throws RemoteException;
}