package sistema;
import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;
import sistema.util.Teclado;
import sistema.util.Destino;

public class EjecutorServer extends Thread implements Ejecutor{
  private KernelImpl server=null;
  private int idCount=1;

  public EjecutorServer(String numero,EnlaceSend grafico){
    int vecindario=0;
    try{
      vecindario=Integer.parseInt(numero);
    }catch(NumberFormatException e){
      println("Error en numero para Servidor.."+numero);
      System.exit(0);
    }
    System.setSecurityManager(new RMISecurityManager());
    String nombreServidor="p"+vecindario;
    try{
      server=new KernelImpl(vecindario,vecindario,this,grafico);
      println("Servidor "+nombreServidor+" Registrado!");
    }catch (Exception e){
      println("Error RMI");
      println(""+e);
      System.exit(0); 
    }    
    server.iniciarDaemon();
  }

  public Object send(int com,Object data,int dest){
    return(server.sendLocal(com,data,dest));
  }

  public int dameID(){
    return(server.dameIdUnico());
  }

  public void close(){
    server.quitaServicio();
    System.exit(0);
  }

  public void run(){
    Teclado lector=new Teclado();
    String s;
    int opc=0;       
    int idVecindario,idVecino;
    Object testObj;
    do{
      opc=0;
      cursor();
      s=new String(lector.read());
      if(s.equals("exit"))opc=99;
      if(s.equals("list"))opc=1;
      if(s.equals("recon"))opc=2;
      if(s.equals("find"))opc=3;
      if(s.equals("send"))opc=4;
      switch(opc){
        case 1:
          if(server.dameEstrella())println("Estrella");
          else println("Anillo Cordado");
          server.listOut(false);
        break;
        case 2:server.ReConect();break;
        case 3:
          println("Input destino:");
          System.out.print("Vecindario:");
          s=new String(lector.read());
          try{
            idVecindario=Integer.parseInt(s);
          }catch(NumberFormatException e1){
            println("Error Numerico Vecindario");
            break;
          }
          System.out.print("Vecino:");
          s=new String(lector.read());
          try{
            idVecino=Integer.parseInt(s);
          }catch(NumberFormatException e1){
            println("Error Numerico Vecino");
            break;
          }
          server.busca(Destino.creaDest(idVecindario,idVecino));
        break;
        case 4:
          println("Input destino:");
          System.out.print("Vecindario:");
          s=new String(lector.read());
          try{
            idVecindario=Integer.parseInt(s);
          }catch(NumberFormatException e1){
            println("Error Numerico Vecindario");
            break;
          }
          System.out.print("Vecino:");
          s=new String(lector.read());
          try{
            idVecino=Integer.parseInt(s);
          }catch(NumberFormatException e1){
            println("Error Numerico Vecino");
            break;
          }
          System.out.print("Mensaje:");
          s=new String(lector.read());
          testObj=send(256,s,Destino.creaDest(idVecindario,idVecino));
          if(testObj!=null)println("Envio Correcto.");
          else println("Fail");   
        break;
        //case 99:server.salir();break; 
      }       
    }while(opc!=99);
    server.quitaServicio();
    System.exit(0);
  }

  private void println(String m){
    System.out.println(m);
  }

  public int dameId(){
    return(idCount++);
  }
  
  public Object send(int orig,int instruction,Object data,int dest){
    Object respuesta=null;
    return(respuesta);
  }

  public void cursor(){
    System.out.print("<S"+server.dameVecindario()+".0># ");
  }  

  public void pierdeConexion(){}

  public void runRMI(){
    server.checaEnlaces(true);
  }

  public KernelInterface salidaServer(){
    return(null);
  }

}