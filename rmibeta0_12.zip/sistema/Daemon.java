package sistema;

public class Daemon extends Thread{
  private Ejecutor cs;
  private int tiempo;
  
  public Daemon(Ejecutor cs,int tiempo){
    this.cs=cs;
    this.tiempo=tiempo;
  }

  public void run(){    
    while(true){
      cs.runRMI();
      try{
        sleep(tiempo);
      }catch(InterruptedException e){}
    }
  }

}