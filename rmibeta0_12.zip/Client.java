import sistema.EnlaceSend;
import sistema.EnlaceClient;
import sistema.util.Destino;

public class Client implements EnlaceSend{
  public EnlaceClient conection;

  public Client(String ip,String num){
    conection=new EnlaceClient(ip,num,(EnlaceSend)(this));
  }

  //Este es el metodoRemoto
  public Object send(int com,Object data,int dest){
    System.out.println("Soy un cliente..");
    System.out.println(Destino.vecindario(dest)+"."+Destino.vecino(dest)+" me pide "+com);
    System.out.println((String)data);
    return(new Boolean(true));
    //return(null);     
  }

  public static void main(String[] argv){
    if(argv.length != 2)System.exit(0);
    Client visual=new Client(argv[0],argv[1]);
  }
}