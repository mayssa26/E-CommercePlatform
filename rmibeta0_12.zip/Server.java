import sistema.EnlaceServer;
import sistema.EnlaceSend;
import sistema.util.Destino;

public class Server implements EnlaceSend{
  public EnlaceServer conection;

  public Server(String ip){
    conection=new EnlaceServer(ip,this);
  }

  //Este es el metodoRemoto
  public Object send(int com,Object data,int dest){
    System.out.println("Soy un Servidor");
    System.out.println(Destino.vecindario(dest)+"."+Destino.vecino(dest)+" me pide "+com);
    System.out.println((String)data);    
    return(new Boolean(true));
    //return(null);     
  }

  public static void main(String[] argv){
    if(argv.length != 1)System.exit(0);
    Server visual=new Server(argv[0]);
  }

}